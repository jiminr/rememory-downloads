// === CONFIG ===
const SERVER_URL = "http://127.0.0.1:5000/analyze";
const MY_ID = "re_mem_ory";

// === STATE ===
let isProcessing = false;
let activeKeywords = [];
let previouslyHighlighted = [];
let riskCache = JSON.parse(localStorage.getItem("riskCache") || "{}");
let processedComments = new Set(JSON.parse(localStorage.getItem("processedComments") || "[]"));

// === UTIL: Cache ===
function sanitizeText(text) {
  return text.replace(/[\n🟥🟧🟨]+/g, '').trim();
}
function cacheRisk(text, score) {
  const rounded = Math.round(score * 1000) / 1000;
  riskCache[text] = rounded;
  localStorage.setItem("riskCache", JSON.stringify(riskCache));
}
function saveProcessed() {
  localStorage.setItem("processedComments", JSON.stringify([...processedComments]));
}
function isCached(text) {
  return riskCache.hasOwnProperty(text);
}
function containsKeyword(text) {
  return activeKeywords.some(k => text.includes(k));
}

// === UI: Keyword Input & List ===
const analyzeBtn = document.createElement('button');
analyzeBtn.textContent = "🧠 유출 습관 분석";
Object.assign(analyzeBtn.style, {
  position: 'fixed', top: '20px', right: '20px', zIndex: '9999',
  padding: '10px', fontSize: '14px', backgroundColor: '#4CAF50',
  color: '#fff', border: 'none', borderRadius: '6px',
  cursor: 'pointer', boxShadow: '0 2px 6px rgba(0,0,0,0.2)'
});
document.body.appendChild(analyzeBtn);
//키워드 저장해서 웹페이지로 보내는 기능
const saveBtn = document.createElement('button');
saveBtn.textContent = "💾 키워드 저장";
Object.assign(saveBtn.style, {
  position: 'fixed', top: '20px', right: '150px', zIndex: '9999',
  padding: '10px', fontSize: '14px', backgroundColor: '#2196F3',
  color: '#fff', border: 'none', borderRadius: '6px',
  cursor: 'pointer', boxShadow: '0 2px 6px rgba(0,0,0,0.2)'
});
document.body.appendChild(saveBtn);

saveBtn.addEventListener('click', async () => {
  if (activeKeywords.length === 0) {
    alert("저장할 키워드가 없습니다.");
    return;
  }

  try {
    const response = await fetch("https://example.com/save_keywords", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        keywords: activeKeywords,
        timestamp: new Date().toISOString()
      })
    });

    const result = await response.json();
    if (result.success) {
      alert("✅ 키워드가 성공적으로 저장되었습니다.");
    } else {
      alert("❌ 저장 실패: " + result.message);
    }
  } catch (err) {
    console.error("저장 중 오류:", err);
    alert("❌ 저장 요청 중 오류 발생");
  }
});

const input = document.createElement('input');
input.type = 'text';
input.placeholder = 'Enter로 키워드 추가/삭제';
Object.assign(input.style, {
  position: 'fixed', top: '60px', right: '20px', zIndex: '9999',
  padding: '8px', fontSize: '16px', border: '2px solid #aaa',
  borderRadius: '6px', backgroundColor: '#fff',
  boxShadow: '0 2px 6px rgba(0,0,0,0.2)'
});
document.body.appendChild(input);

const keywordList = document.createElement('div');
keywordList.id = "keywordList";
Object.assign(keywordList.style, {
  position: 'fixed', top: '100px', right: '20px', zIndex: '9999',
  maxWidth: '200px', padding: '10px', backgroundColor: '#f0f8ff',
  border: '2px solid #aaa', borderRadius: '6px',
  boxShadow: '0 2px 6px rgba(0,0,0,0.2)', fontSize: '14px',
  fontFamily: 'sans-serif'
});
document.body.appendChild(keywordList);

analyzeBtn.addEventListener('click', () => {
  const top10 = getTop10DangerousComments();
  console.log("🔹 [1단계] 상위 10개 위험 댓글:", top10);

  if (top10.length === 0) {
    alert("위험 댓글이 없습니다.");
    return;
  }

  chrome.runtime.sendMessage(
    {
      type: "analyze_habits",
      comments: top10
    },
    (response) => {
      console.log("🔹 [4단계] background 응답 수신:", response);
      if (response?.success) {
        alert("🧠 분석 결과:\n\n" + response.result);
      } else {
        alert("❌ 분석 실패: " + (response?.error || "응답 없음"));
      }
    }
  );
});

// === Keyword Save/Load/Render ===
function saveKeywords() {
  localStorage.setItem("myKeywords", JSON.stringify(activeKeywords));
}
function loadKeywords() {
  const saved = localStorage.getItem("myKeywords");
  if (saved) activeKeywords = JSON.parse(saved);
}
function renderKeywordList() {
  keywordList.innerHTML = "<b>📘 키워드 목록</b><br/>";
  if (activeKeywords.length === 0) {
    keywordList.innerHTML += "<i style='color:gray;'>없음</i>";
    return;
  }
  activeKeywords.forEach((kw, index) => {
    const item = document.createElement("div");
    item.style.marginTop = "4px";
    const span = document.createElement("span");
    span.textContent = `• ${kw}`;
    span.style.marginRight = "8px";
    const del = document.createElement("button");
    del.textContent = "❌";
    del.style.fontSize = "10px";
    del.style.cursor = "pointer";
    del.onclick = () => {
      activeKeywords.splice(index, 1);
      saveKeywords();
      applyKeywordHighlighting();
      renderKeywordList();
    };
    item.appendChild(span);
    item.appendChild(del);
    keywordList.appendChild(item);
  });
}

// === Input Handler ===
input.addEventListener('keydown', function (e) {
  if (e.key === 'Enter') {
    e.preventDefault();
    const keyword = this.value.trim();
    if (keyword.length === 0) return;
    toggleKeyword(keyword);
    this.value = '';
  }
});
function toggleKeyword(keyword) {
  const index = activeKeywords.indexOf(keyword);
  if (index > -1) {
    activeKeywords.splice(index, 1);
  } else {
    activeKeywords.push(keyword);
  }
  saveKeywords();
  applyKeywordHighlighting();
  renderKeywordList();
}

// === Highlight ===
function resetHighlighting() {
  for (const el of previouslyHighlighted) {
    el.style.border = "";
    el.style.padding = "";
    el.style.backgroundColor = "";
    el.title = "";
  }
  previouslyHighlighted = [];
}
function applyKeywordHighlighting() {
  resetHighlighting();
  if (activeKeywords.length === 0) return;
  const myDivs = getMyCommentsOnly();
  for (const div of myDivs) {
    const spans = div.querySelectorAll("span");
    for (const span of spans) {
      const text = span.innerText || '';
      const matched = activeKeywords.filter(k => text.includes(k));
      if (matched.length > 0) {
        span.style.border = "2px solid blue";
        span.style.padding = "4px";
        span.style.backgroundColor = "#eaf4ff";
        span.title = `🔵 포함 키워드: ${matched.join(', ')}`;
        previouslyHighlighted.push(span);
      }
    }
  }
}

// === My Comments ===
function getMyCommentsOnly() {
  const allDivs = Array.from(document.querySelectorAll('div[dir="auto"]'));
  return allDivs.filter(div => {
    const text = div.innerText.trim();
    if (text.length < 3 || !div.offsetParent) return false;
    const parent = div.closest("div");
    const span = parent?.querySelector("span");
    return span && span.innerText.includes(MY_ID);
  });
}

// === Risk Box Highlight ===
function highlight(divs, risks) {
  divs.forEach((div, i) => {
    const riskData = risks[i];
    if (!riskData) return;
    const score = riskData.score || 0;
    let color = "", riskLevel = "", emoji = "";
    if (score >= 0.8) {
      color = "#ff4444"; riskLevel = "매우 높음"; emoji = "🟥";
    } else if (score >= 0.7) {
      color = "#ff8800"; riskLevel = "중간 위험"; emoji = "🟧";
    } else if (score >= 0.6) {
      color = "#ffdd00"; riskLevel = "낮은 위험"; emoji = "🟨";
    } else {
      return;
    }
    div.style.border = `3px solid ${color}`;
    div.style.borderRadius = "6px";
    div.style.padding = "6px";
    div.style.backgroundColor = `${color}15`;
    div.style.position = "relative";
    const badge = document.createElement('div');
    badge.style.cssText = `position:absolute;top:-8px;right:-8px;background:${color};color:white;padding:2px 6px;border-radius:10px;font-size:10px;font-weight:bold;z-index:1000;pointer-events:none;`;
    badge.textContent = emoji;
    div.appendChild(badge);
    div.title = `${emoji} 개인정보 유출 위험도: ${riskLevel} (점수: ${score})`;
  });
}
function getTop10DangerousComments() {
  return Object.entries(riskCache)
    .filter(([_, score]) => score >= 0.6)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 10)
    .map(([text, score]) => ({ text, score }));
}

// === Debounce ===
function debounce(fn, delay = 500) {
  let timeout;
  return (...args) => {
    clearTimeout(timeout);
    timeout = setTimeout(() => fn(...args), delay);
  };
}

// === Mutation Observer ===
function observeMyComments() {
  const observer = new MutationObserver(debounce(async () => {
    if (isProcessing) return;
    const myDivs = getMyCommentsOnly();
    const texts = myDivs.map(div => div.innerText.trim());
    const newTexts = [], newDivs = [];

    texts.forEach(text => {
      const cleanText = sanitizeText(text);
      if (isCached(cleanText)) {
        const div = myDivs.find(d => sanitizeText(d.innerText.trim()) === cleanText);
        if (div) highlight([div], [{ score: riskCache[cleanText] }]);
        processedComments.add(cleanText);
      } else if (!processedComments.has(cleanText)) {
        newTexts.push(cleanText);
      }
    });

    newDivs.push(...myDivs.filter(div => newTexts.includes(sanitizeText(div.innerText.trim()))));

    if (newTexts.length > 0) {
      isProcessing = true;
      try {
        const res = await fetch(SERVER_URL, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ comments: newTexts })
        });
        const result = await res.json();
        highlight(newDivs, result);
        newTexts.forEach((text, i) => {
          const score = result[i]?.score;
          if (score !== undefined) {
            const cleanText = sanitizeText(text);
            cacheRisk(cleanText, score);
            processedComments.add(cleanText);
          }
        });
        saveProcessed();
      } catch (e) {
        console.error("❌ 분석 서버 실패:", e);
      } finally {
        isProcessing = false;
      }
    }
    applyKeywordHighlighting();
  }));

  observer.observe(document.body, { childList: true, subtree: true });
  window.addEventListener('beforeunload', () => observer.disconnect());
}

// === INIT ===
console.log("🚀 개인정보 감지 시스템 실행");
loadKeywords();
renderKeywordList();

if (document.readyState !== 'complete') {
  window.addEventListener('load', () => {
    observeMyComments();
  });
} else {
  observeMyComments();
}
// [Test Button 생성]
const testBtn = document.createElement("button");
testBtn.textContent = "🔍 OpenAI 테스트";
testBtn.style.position = "fixed";
testBtn.style.bottom = "20px";
testBtn.style.right = "20px";
testBtn.style.zIndex = "9999";
testBtn.style.padding = "10px";
testBtn.style.backgroundColor = "green";
testBtn.style.color = "white";
testBtn.style.borderRadius = "6px";
testBtn.style.border = "none";
document.body.appendChild(testBtn);

// [버튼 클릭 시 background로 메시지 전송]
testBtn.addEventListener("click", () => {
  chrome.runtime.sendMessage({ type: "openai_test" }, (response) => {
    if (response?.result) {
      alert("✅ OpenAI 응답: " + response.result);
    } else {
      alert("❌ 오류: " + (response?.error || "알 수 없는 오류"));
    }
  });
});
